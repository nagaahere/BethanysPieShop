export * from './tour-add/tour-add.component';
export * from './tour-detail/tour-detail.component';
export * from './tour-update/tour-update.component';
export * from './tours.component';