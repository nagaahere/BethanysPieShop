export class Tour {
    tourId: string;    
    band: string;
    title: string;
    description: string;   
    startDate: Date;
    endDate: Date;
}
