import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-add',
  templateUrl: './show-add.component.html',
  styleUrls: ['./show-add.component.css']
})

export class ShowAddComponent implements OnInit { 

  ngOnInit() {
  }
}
