export class Band {
    bandId: string;    
    name: string;
}
