export class Show  {
    showId: string;
    venue: string;
    city: string;
    country: string;
    date: Date;
}
