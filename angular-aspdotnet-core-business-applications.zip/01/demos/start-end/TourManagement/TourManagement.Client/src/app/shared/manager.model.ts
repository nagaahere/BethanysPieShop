export class Manager {
    managerId : string;
    name : string
}
