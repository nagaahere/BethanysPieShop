﻿using System;

namespace TourManagement.API.Dtos
{
    public class Show : ShowAbstractBase
    {
        public Guid ShowId { get; set; }      
    }
}
 