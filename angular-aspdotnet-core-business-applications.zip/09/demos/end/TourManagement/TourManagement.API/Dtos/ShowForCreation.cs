﻿namespace TourManagement.API.Dtos
{
    public class ShowForCreation : ShowAbstractBase
    {
    }
}
