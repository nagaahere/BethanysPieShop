import { ShowAbstractBase } from "./show-abstract-base.model";

export class ShowForCreation extends ShowAbstractBase {
}
