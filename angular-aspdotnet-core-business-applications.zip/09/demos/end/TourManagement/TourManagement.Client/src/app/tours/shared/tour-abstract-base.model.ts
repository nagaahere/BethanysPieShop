export abstract class TourAbstractBase { 
    title: string;
    description: string; 
    startDate: Date;
    endDate: Date;
    }