export class ShowAbstractBase {
    venue: string;
    city: string;
    country: string;
    date: Date;
}
