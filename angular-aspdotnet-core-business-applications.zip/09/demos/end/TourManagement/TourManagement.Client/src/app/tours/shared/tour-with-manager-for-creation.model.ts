import { TourForCreation } from "./tour-for-creation.model";

export class TourWithManagerForCreation extends TourForCreation {
    managerId: string;
}
